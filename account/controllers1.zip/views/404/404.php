<HTML>

<HEAD>

<title> 404 Error Page</title>

</HEAD>

<BODY>

<p align="center">

<h1>Error 404</h1><br>Page Not Found



Visit our Home Page  <a href="<?php echo $baseurl;?>">New Jibon Varaity Store</a>
</p>

</BODY></HTML>